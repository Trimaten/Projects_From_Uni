`218482`, `Ngoc Tri Nguyen`
`218483`, `Leonard Winter`
`218449`, `Richard Mueller`

### Link zum Youtube Video:
[SmartHome Device](https://www.youtube.com/watch?v=-8qxF15kieE)

### Github repo where all gifs and videos are
[Github Repo](https://github.com/Kotfresse/HHN-SV2-Doc/tree/main)